# SCINApy
python version of R package SCINA
